# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'badb7af096f9446fd5ab7e5b40e5e72ad3d55f3e87ffdc02ab428285141f3be0afee14e41bfad6e16fc97f12fcc079b35b65ad7d97b97671820738644c35d7f4'
